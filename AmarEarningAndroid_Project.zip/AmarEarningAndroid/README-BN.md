# Amar Earning Android App

এটি Amar Earning website-কে Android WebView app হিসেবে চালানোর জন্য প্রস্তুত করা project।

Website:
https://amarearning.site/

## কী আছে
- Amar Earning branding
- Full-screen WebView
- JavaScript + local storage
- Login/session cookie support
- Android back button
- File picker support
- Download/external-link handling
- Loading indicator

## APK build
Android Studio-তে project folder খুলুন।
তারপর:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

Release APK/Play Store AAB বানানোর আগে app signing এবং Play Console configuration করতে হবে।

## গুরুত্বপূর্ণ
Website-এর payment, login, task, wallet বা earning logic এই app-এ আলাদা করে লেখা হয়নি। App সরাসরি existing website ব্যবহার করে, তাই website-এ পরিবর্তন করলে app-এও পরিবর্তন দেখা যাবে।